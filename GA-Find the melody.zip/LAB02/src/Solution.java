import org.jfugue.player.Player;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Random;
public class Solution {

    private ArrayList<Melody> CandidateSolutions = new ArrayList<>();
    private ArrayList<Melody> ParentSolutions = new ArrayList<>();
    private ArrayList<Melody> ChildSolutions = new ArrayList<>();
    private double MaxNoteNum;
    private int populationNumber;
    private int maxGen;
    private double crossoverProb;
    private double mutationProb;
    private double bestFitness;
    private String wantedMelody;
    private  int playNote;


    public Solution(double maxNoteNum, int populationNumber, int maxGen, double crossoverProb, double mutationProb,String wantedMelody,int playNote) {
        MaxNoteNum = maxNoteNum;
        this.populationNumber = populationNumber;
        this.maxGen = maxGen;
        this.crossoverProb = crossoverProb;
        this.mutationProb = mutationProb;
        this.wantedMelody=wantedMelody;
        this.playNote=playNote;

        CandidateSolutions = generateMelody();
        double startTime = System.currentTimeMillis();
        for (int i = 0; i<maxGen;i++) {
            fitnessFunction(CandidateSolutions);
            selection();
            child();
            fitnessFunction(ChildSolutions);
            merge(ParentSolutions, ChildSolutions);
            output(i+1);
            double estimatedTime = System.currentTimeMillis() - startTime;
            System.out.println("Vrijeme: "+estimatedTime/1000+" s.");
        }


    }

    public ArrayList<Melody> generateMelody(){
        for (int i = 0; i < populationNumber;i++){
            Melody melody = new Melody("", 0);
            for (int j = 0; j < MaxNoteNum;j++){
                if(melody.getName().isEmpty()){
                    melody.setName(Note.getRandomNote().getName());
                }else {
                    melody.setName(melody.getName()+" "+Note.getRandomNote().getName());
                }
            }
            CandidateSolutions.add(melody);
        }
        return CandidateSolutions;
    }

    public void output(int gen){
        Player player = new Player();

        System.out.println("Generacija: "+gen+".");
        Melody bestGenSolution=bestFitness(CandidateSolutions);
        System.out.println(bestGenSolution.getName()+" "+bestGenSolution.getFitness());
        if(gen%playNote==0) {
            player.play(bestGenSolution.getName());
        }

    }

    public Melody bestFitness(ArrayList<Melody>Candidates){
        Melody bestSol = Candidates.get(0);

        for (Melody melody : Candidates) {
            if (melody.getFitness()<bestSol.getFitness()) {
                bestSol =melody;
            }
        }
        return bestSol;
    }
    public void fitnessFunction(ArrayList<Melody>Candidates){
        int wantedNum=0;
        int givenNum=0;
        String []wantedNotes=wantedMelody.split(" ");
        for(Melody melody: Candidates){
            String [] givenNotes=melody.getName().split(" ");
            for(int i=0; i<MaxNoteNum;i++){
                for(Note note: Note.values()){
                    if(note.getName().equals(wantedNotes[i])){
                        wantedNum = note.getNum();
                    } if(note.getName().equals(givenNotes[i])){
                        givenNum = note.getNum();
                    }
                }
                melody.setFitness(melody.getFitness()+Math.abs(wantedNum - givenNum));
            }

        }
    }

    public void selection(){
        ParentSolutions = new ArrayList<>();
        ChildSolutions = new ArrayList<>();
        for(int i=0;i<populationNumber/2-2;i++){
            Random random =new Random();
            int a= random.nextInt(CandidateSolutions.size());
            Melody melodyOne=CandidateSolutions.get(a);
            CandidateSolutions.remove(melodyOne);
            int b=random.nextInt(CandidateSolutions.size());
            Melody melodyTwo=CandidateSolutions.get(b);
            CandidateSolutions.remove(melodyTwo);
            ParentSolutions.add(tournament(melodyOne,melodyTwo));
        }
    }
    public Melody tournament(Melody melodyOne, Melody melodyTwo){
        if(melodyOne.getFitness()>melodyTwo.getFitness()){
            return melodyTwo;
        }else{
            return melodyOne;
        }

    }
    public void child(){
        for(int i=0;i<ParentSolutions.size();i+=2){
            if(ParentSolutions.size()%2==0) {
                Melody one = ParentSolutions.get(i);
                Melody two = ParentSolutions.get(i + 1);
                crossover(one, two);
            }else{
                if(i==ParentSolutions.size()-1){
                    Random random = new Random();
                    int x = random.nextInt(ParentSolutions.size() - 2);
                    Melody one = ParentSolutions.get(i);
                    Melody two = ParentSolutions.get(x);
                    crossover(one, two);

                }else {
                    Melody one = ParentSolutions.get(i);
                    Melody two = ParentSolutions.get(i + 1);
                    crossover(one, two);
                }
            }
        }
    }
    public void crossover(Melody one, Melody two){
        int crossNum= (int) Math.round(crossoverProb*MaxNoteNum);
        String [] tmpOne=one.getName().split(" ");
        String[]tmpTwo=two.getName().split(" ");
        Melody childOne=new Melody("",0);
        Melody childTwo=new Melody("",0);

        String childOneString = "";
        String childTwoString= "";

        for(int i=0;i<MaxNoteNum;i++){
            if(i<crossNum){
                if(i==0){
                    childOneString=childTwoString+tmpOne[i];
                    childTwoString=childTwoString+tmpTwo[i];
                }else{
                    childOneString=childTwoString+" "+tmpOne[i];
                    childTwoString=childTwoString+" "+tmpTwo[i];
                }
            }else{
                childOneString=childTwoString+" "+tmpTwo[i];
                childTwoString=childTwoString+" "+tmpOne[i];
            }
        }
        childOne.setName(mutation(childOneString));
        childTwo.setName(mutation(childTwoString));


        ChildSolutions.add(childOne);
        ChildSolutions.add(childTwo);
    }
    public String mutation (String childString){
        String childMutationString="";
        String[]tmpChild=childString.split(" ");
        for(int i=0;i<tmpChild.length;i++){
            if(Math.random()<mutationProb){
                tmpChild[i]=Note.getRandomNote().getName();
            }
            if(i==0){
                childMutationString=childMutationString+ tmpChild[i];
            }else{
                childMutationString=childMutationString+" "+ tmpChild[i];
            }
        }

        return childMutationString;
    }

    public void merge(ArrayList<Melody>ParentSolutin,ArrayList<Melody>ChildSolution){
        if(ChildSolution.size()!=ParentSolutin.size()) {
            Random random = new Random();
            int x = random.nextInt(ChildSolution.size());
            ChildSolutions.remove(x);
        }

        ParentSolutin.addAll(ChildSolution);
        CandidateSolutions = ParentSolutin;
    }

}
