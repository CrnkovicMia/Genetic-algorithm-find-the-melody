import org.jfugue.player.Player;

public class Main {
    public static void main(String[] args) {

        double MaxNoteNum = 10;
        int populationNumber = 500;
        int maxGen = 1200;
        double crossoverProb = 0.9;
        double mutationProb = 0.03;
        String wantedMelody="C1w D1w E2h Fw G2#h C1w D1w E2h Fw G2#h";
        int playNote=20;

        Solution melody = new Solution(MaxNoteNum, populationNumber, maxGen, crossoverProb, mutationProb,wantedMelody,playNote);
    }
}