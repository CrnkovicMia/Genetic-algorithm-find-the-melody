public class Melody {
    private String name;
    private int fitness;

    public Melody(String name, int fitness) {
        this.name = name;
        this.fitness = fitness;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFitness() {
        return fitness;
    }

    public void setFitness(int fitness) {
        this.fitness = fitness;
    }
}
