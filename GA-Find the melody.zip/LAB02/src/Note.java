import java.util.Random;

public enum Note {
    //Prva skala
    Ci("Ci",1),
    Cq("Cq",2),
    Ch("Ch",3),
    C("Cw",4),

    Cshi("C#i",5),
    Cshq("C#q",6),
    Cshh("C#h",7),
    Cshw("C#w",8),

    Di("Di",9),
    Dq("Dq",10),
    Dh("Dh",11),
    Dw("Dw",12),

    Dshi("D#i",13),
    Dshq("D#q",14),
    Dshh("D#h",15),
    Dshw("D#w",16),

    Ei("Ei",17),
    Eq("Eq",18),
    Eh("Eh",19),
    Ew("Ew",20),

    Fi("Fi",21),
    Fq("Fq",22),
    Fh("Fh",23),
    Fw("Fw",24),

    Fshi("F#i",25),
    Fshq("F#q",26),
    Fshh("F#h",27),
    Fshw("F#w",28),

    Gi("Gi",29),
    Gq("Gq",30),
    Gh("Gh",31),
    Gw("Gw",32),

    Gshi("G#i",33),
    Gshq("G#q",34),
    Gshh("G#h",35),
    Gshw("G#w",36),

    Ai("Ai",37),
    Aq("Aq",38),
    Ah("Ah",39),
    Aw("Aw",40),

    Ashi("A#i",41),
    Ashq("A#q",42),
    Ashh("A#h",43),
    Ashw("A#w",44),

    Bi("Bi",45),
    Bq("Bq",46),
    Bh("Bh",47),
    Bw("Bw",48),

    //Druga skala
    C2i("C2i",49),
    C2q("C2q",50),
    C2h("C2h",51),
    C2("C2w",52),

    C2shi("C2#i",53),
    C2shq("C2#q",54),
    C2shh("C2#h",55),
    C2shw("C2#w",56),

    D2i("D2i",57),
    D2q("D2q",58),
    D2h("D2h",59),
    D2w("D2w",60),

    D2shi("D2#i",61),
    D2shq("D2#q",62),
    D2shh("D2#h",63),
    D2shw("D2#w",64),

    E2i("E2i",65),
    E2q("E2q",66),
    E2h("E2h",67),
    E2w("E2w",68),

    F2i("F2i",69),
    F2q("F2q",70),
    F2h("F2h",71),
    F2w("F2w",72),

    F2shi("F2#i",73),
    F2shq("F2#q",74),
    F2shh("F2#h",75),
    F2shw("F2#w",76),

    G2i("G2i",77),
    G2q("G2q",78),
    G2h("G2h",79),
    G2w("G2w",80),

    G2shi("G2#i",81),
    G2shq("G2#q",82),
    G2shh("G2#h",83),
    G2shw("G2#w",84),

    A2i("A2i",85),
    A2q("A2q",86),
    A2h("A2h",87),
    A2w("A2w",88),

    A2shi("A2#i",89),
    A2shq("A2#q",90),
    A2shh("A2#h",91),
    A2shw("A2#w",92),

    B2i("B2i",93),
    B2q("B2q",94),
    B2h("B2h",95),
    B2w("B2w",96),

    //Treca oktava
    C3i("C3i",97),
    C3q("C3q",98),
    C3h("C3h",99),
    C3("C3w",100),

    C3shi("C3#i",101),
    C3shq("C3#q",102),
    C3shh("C3#h",103),
    C3shw("C3#w",104),

    D3i("D3i",105),
    D3q("D3q",106),
    D3h("D3h",107),
    D3w("D3w",108),

    D3shi("D3#i",109),
    D3shq("D3#q",110),
    D3shh("D3#h",111),
    D3shw("D3#w",112),

    E3i("E3i",113),
    E3q("E3q",114),
    E3h("E3h",115),
    E3w("E3w",116),

    F3i("F3i",117),
    F3q("F3q",118),
    F3h("F3h",119),
    F3w("F3w",120),

    F3shi("F3#i",121),
    F3shq("F3#q",122),
    F3shh("F3#h",123),
    F3shw("F3#w",124),

    G3i("G3i",125),
    G3q("G3q",126),
    G3h("G3h",127),
    G3w("G3w",128),

    G3shi("G3#i",129),
    G3shq("G3#q",130),
    G3shh("G3#h",131),
    G3shw("G3#w",132),

    A3i("A3i",133),
    A3q("A3q",134),
    A3h("A3h",135),
    A3w("A3w",136),

    A3shi("A3#i",137),
    A3shq("A3#q",138),
    A3shh("A3#h",139),
    A3shw("A3#w",140),

    B3i("B3i",141),
    B3q("B3q",142),
    B3h("B3h",143),
    B3w("B3w",144);

    private String name;
    private int num;

    Note(String name, int num) {
        this.name = name;
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public int getNum() {
        return num;
    }

    public static Note getRandomNote() {
        Random random = new Random();
        Note note = values()[random.nextInt(values().length)];
        return note;
    }
}
